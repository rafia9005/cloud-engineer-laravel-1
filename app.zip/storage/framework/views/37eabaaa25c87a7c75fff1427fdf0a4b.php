<?php $__env->startSection('main'); ?>
    <h1>hello world</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/welcome.blade.php ENDPATH**/ ?>